//
//  ViewController.swift
//  RainbowTabs
//
//  Created by 2020-1 on 9/6/19.
//  Copyright © 2019 macbook. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        tabBarItem.badgeValue = "45"
    }

    //Labs
    //353 yiii
    //620 uwu

}

