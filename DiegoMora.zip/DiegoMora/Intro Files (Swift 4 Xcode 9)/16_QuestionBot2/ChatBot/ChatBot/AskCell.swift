import UIKit

/// Contiene un campo de texto para que el usuario escriba una pregunta
class AskCell: UITableViewCell {

    @IBOutlet weak var textField: UITextField!

}
