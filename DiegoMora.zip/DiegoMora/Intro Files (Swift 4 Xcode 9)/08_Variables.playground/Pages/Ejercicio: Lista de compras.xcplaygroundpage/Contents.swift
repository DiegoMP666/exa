/*:
 ## Ejercicio: Crear una lista de compras

 Las siguientes constantes representan algunos de los productos que tal vez debas agregar a una lista de compras:
*/
let eggs = "Huevos"
let milk = "Leche"
let cheese = "Queso"
let bread = "Pan"
let rice = "Arroz"
let newLine = "\n"
//: - callout(Exercise):
//:(Ejercicio):\
//:En este ejercicio, debes crear una cadena variable con un valor inicial de `""`. Agrega a la lista todos los elementos constantes especificados arriba, uno por uno. Agrega `newLine` (nueva línea) entre cada elemento. Recuerda que puedes unir dos cadenas con el operador `+`.






//: [Anterior](@previous)  |  Página 12 de 13  |  [Siguiente: Ejercicio: 501](@next)
