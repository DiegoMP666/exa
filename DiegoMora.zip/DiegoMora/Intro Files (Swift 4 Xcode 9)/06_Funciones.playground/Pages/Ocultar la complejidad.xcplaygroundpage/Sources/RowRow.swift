public func rowTheBoat() {
    print("Rema, rema, rema tu bote")
    print("Alegre por el río")
}
public func merrilyDream() {
    print("Rápido, rápido, rápido, rápido")
    print("Rema en el barquito")
}
public func crocodileScream() {
    print("Y si ves un cocodrilo")
    print("Pega un buen grito")
}
public func repetitiveTheme() {
    print("Esta letra se repite")
    print("Cuál es el objetivo")
}
public func breatheBetweenVerses() {
    print("        ~        ")
}
public func verseOne() {
    rowTheBoat()
    merrilyDream()
}
public func verseTwo() {
    rowTheBoat()
    crocodileScream()
}
public func verseThree() {
    rowTheBoat()
    repetitiveTheme()
}

