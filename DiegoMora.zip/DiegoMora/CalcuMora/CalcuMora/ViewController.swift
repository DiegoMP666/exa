//
//  ViewController.swift
//  CalcuMora
//
//  Created by 2020-1 on 8/16/19.
//  Copyright © 2019 saladitas. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

