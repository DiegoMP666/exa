//
//  ViewController.swift
//  HelloWorld
//
//  Created by 2020-1 on 8/9/19.
//  Copyright © 2019 unam. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func unwindToPortada(unwindSegue:UIStoryboardSegue){
        
    }


}

